#include <iostream>
#include "animal.h"
#include <QFile>
#include <QDebug>

using namespace std;

int main(int argc, char *argv[])
{
    QFile file("data.bin");

    if( ! file.open(QIODevice::WriteOnly))
        return -1;

    Animal* a = new Animal;
    a->setName("Rex");
    a->setType("dog");
    a->setAge(12);
    a->setWeight(3);

    QDataStream out(&file);
    a->setAge(10);
    out << a;
    a->setAge(20);
    a->setName("Jerry");
    out << a;
    a->setAge(30);
    a->setName("Grivei");
    out << a;
    file.close();

    Animal* b = new Animal;
    if( ! file.open(QIODevice::ReadOnly))
        return -1;

    QDataStream in(&file);
    in >> b;
    qDebug() << b->toString();
    in >> b;
    qDebug() << b->toString();
    in >> b;
    qDebug() << b->toString();

    return 0;
}
