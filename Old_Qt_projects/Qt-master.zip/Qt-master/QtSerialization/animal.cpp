#include "animal.h"

Animal::Animal(QObject *parent) : QObject(parent)
{
    this->name = "";
    this->type = "";
    this->age = 0;
    this->weight = 0;
}

Animal::Animal(QString n, QString t, unsigned int a, QObject *parent): QObject(parent)
{
    this->name = n;
    this->type = t;
    this->age = a;
    this->weight = 0;
}

QString Animal::toString() const
{
    QString ret = "";
    ret += getName();
    ret += " is a " + getType();
    ret += QString(", %1 years").arg(getAge());
    ret += QString(", %1 kg").arg(getWeight());

    return ret;
}

unsigned int Animal::getWeight() const
{
    return weight;
}

void Animal::setWeight(unsigned int value)
{
    weight = value;
}

QString Animal::getName() const
{
    return name;
}

void Animal::setName(const QString &value)
{
    name = value;
}

QString Animal::getType() const
{
    return type;
}

void Animal::setType(const QString &value)
{
    type = value;
}

unsigned int Animal::getAge() const
{
    return age;
}

void Animal::setAge(unsigned int value)
{
    age = value;
}

QDataStream &operator <<(QDataStream &out, const Animal* animal)
{
    out << animal->getName() << animal->getType() << animal->getAge() << animal->getWeight();
    return out;
}

QDataStream &operator >>(QDataStream &in, Animal* animal)
{
    QString n, t;
    unsigned int a, w;

    in >> n >> t >> a >> w;
    animal->setName(n);
    animal->setType(t);
    animal->setAge(a);
    animal->setWeight(w);

    return in;
}
