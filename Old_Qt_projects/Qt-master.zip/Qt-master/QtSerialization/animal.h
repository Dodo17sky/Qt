#ifndef ANIMAL_H
#define ANIMAL_H

#include <QObject>
#include <QString>
#include <QDataStream>

class Animal : public QObject
{
    Q_OBJECT
public:
    explicit Animal(QObject *parent = 0);
    explicit Animal(QString n, QString t, unsigned int a, QObject *parent = 0);
    QString toString() const;

    unsigned int getWeight() const;
    void setWeight(unsigned int value);

    QString getName() const;
    void setName(const QString &value);

    QString getType() const;
    void setType(const QString &value);

    unsigned int getAge() const;
    void setAge(unsigned int value);

signals:

public slots:

private:
    QString name;
    QString type;
    unsigned int age;
    unsigned int weight;
};

QDataStream& operator <<(QDataStream& out, const Animal* animal);
QDataStream& operator >>(QDataStream& in ,       Animal* animal);

#endif // ANIMAL_H
